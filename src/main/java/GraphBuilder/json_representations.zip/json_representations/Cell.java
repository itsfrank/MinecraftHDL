package GraphBuilder.json_representations;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Francis O'Brien - 4/3/2017 - 19:39
 */

public class Cell extends Node{

    String type;
    HashMap<String, String> port_directions;
    HashMap<String, int[]> connections;

    HashMap<String, Port> ports = new HashMap<>();

    @Override
    public ArrayList<Integer> getNets() {
        return null;
    }

    public void posInit(){
        for (String p : port_directions.keySet()){
            ports.put(p, new Port(port_directions.get(p), connections.get(p)));
        }
    }

    public void print(int tabs) {
        System.out.println(JsonFile.tabs(tabs) + "type: " + type);
        System.out.println(JsonFile.tabs(tabs) + "Ports: " + type);

        for (String p : ports.keySet()){
            System.out.println(JsonFile.tabs(tabs + 1) + p);
            ports.get(p).print(tabs + 1);
        }
    }
}
