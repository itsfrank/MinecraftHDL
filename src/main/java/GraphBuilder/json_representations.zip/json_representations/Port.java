package GraphBuilder.json_representations;

import java.util.ArrayList;

/**
 * Created by Francis O'Brien - 4/3/2017 - 19:39
 */

public class Port extends Node {

    String direction;
    int[] bits;

    public Port(String direction, int[] bits) {
        this.direction = direction;
        this.bits = bits;
    }

    @Override
    public ArrayList<Integer> getNets() {
        return null;
    }

    public void print(int tabs) {
        System.out.println(JsonFile.tabs(tabs) + "direction: " + direction);
        System.out.println(JsonFile.tabs(tabs) + "bits:");
        for(int i : bits){
            System.out.println(JsonFile.tabs(tabs + 1) + i);

        }

    }


}
