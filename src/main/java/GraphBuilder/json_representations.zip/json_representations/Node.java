package GraphBuilder.json_representations;

import java.util.ArrayList;

/**
 * Created by Francis O'Brien - 4/3/2017 - 19:39
 */

abstract public class Node {

    abstract public ArrayList<Integer> getNets();


}
