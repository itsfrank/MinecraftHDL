package GraphBuilder.json_representations;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * Created by Francis O'Brien - 4/3/2017 - 19:48
 */

public class JsonParseTest {

    public static void main(String[] args) {
        try {

            Gson gson = new Gson();
            JsonReader reader = new JsonReader(new FileReader("./run/verilog_designs/adder.json"));
            JsonFile jf = gson.fromJson(reader, JsonFile.class);
            jf.postInit();
            jf.print();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
